const { name } = require('./package.json');
const vue = require('rollup-plugin-vue').default;
const css = require('rollup-plugin-css-only');

module.exports = {
    banner: true,
    output: {
        extractCSS: true,
    },
    plugins: {
        vue: true
    }
};